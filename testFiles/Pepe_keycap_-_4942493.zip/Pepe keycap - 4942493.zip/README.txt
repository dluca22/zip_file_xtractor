Pepe keycap by JohnnyFerg on Thingiverse: https://www.thingiverse.com/thing:4942493

Summary:
Its a MX style Pepe Keycap